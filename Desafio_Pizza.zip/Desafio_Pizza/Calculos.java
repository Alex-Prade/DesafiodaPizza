package Desafio_Pizza;

public class Calculos {
	private static int length;
	private float[]preco = new float[1];;
	private float[]tamanho = new float[3];
	private String[]nome  = new String[1];
	private Calculos[] pizza = new Calculos[1];
	private double[] custoBene = new double[1];
	private double melhorCusto = 999;
	
	public double[] getcustoBene() {		
		return custoBene;
	}
	/**
	 * @param preco the preco to set
	 */
	public void setcustoBene(double[]custoBene) {
		this.custoBene = custoBene;
	}
		
	/**	
	 * 
	 * @return the preco
	 */
	public float[] getPreco() {
		return preco;
	}
	/**
	 * @param preco the preco to set
	 */
	public void setPreco(float[]preco) {
		this.preco= preco;
	}
	/**
	 * @return the tamanho
	 */
	public float[] getTamanho() {
		return tamanho;
	}
	/**
	 * @param tamanho the tamanho to set
	 */
	public void setTamanho(float[]tamanho) {
		this.tamanho = tamanho;
	}
	/**
	 * @return the nome
	 */
	public String[] getNome() {
		return nome;
	}
	/**
	 * @param nome the nome to set
	 */
	public void setNome(String[]nome) {
		this.nome = nome;
	}
	public float[] melhorCusto() {

		return tamanho;
	}
	public float[] calcCusto() {
		return preco;
		
	}
	public int[] novoEspaco() {
		int[]velhoArray = new int[1];
		int[] novoArray =  new int[velhoArray.length];

			for(int i = 0; i < velhoArray.length; i++) {
				novoArray[i] = velhoArray[i];
	    

		}
			return novoArray;
	}
	public String validaTamanho(float tamanho2) {
		
		// Se repetira ate que tenha certeza de que n�o h� valores duplicados
		novoEspaco();
			for (int i = 0; i < tamanho.length + 1; i++) {
				if(tamanho[i] == tamanho2) {
					tamanho2 = 0;
					return "Tamanho j� computado, informe outro.";
					
				}
				else if(tamanho[i] == 0){
				setTamanho(tamanho);	tamanho[i] = tamanho2;
					break;
				}
			}
		
		return "Pizza adicionada com sucesso!";
		
	}
	public Calculos[]novaPizza() {
		novoEspaco();
		setNome(nome);
		setTamanho(tamanho);
		setPreco(preco);
		setcustoBene(custoBene);
		return pizza;
		
	}
	//descobrir o custo da pizza
	public double[] calcMedio () {
		for (int i = 0; i < Calculos.length; i++) {
			float raio = tamanho[i]/2;
			double area = ((raio * raio) * Math.PI);
			custoBene[i] = preco[i]/area;
		}
		return custoBene;
	}
	public double melhorCustoBene() {
		for (int i = 0; i < custoBene.length; i++) {
			if(melhorCusto > custoBene[i] ) {
				melhorCusto = custoBene[i]; 
			}
			
		}
		return melhorCusto;
	}
}	
