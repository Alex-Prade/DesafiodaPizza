package Desafio_Pizza;

import java.util.Scanner;

public class Tela {

	public static void main(String[] args) {
		
		Calculos calc = new Calculos();
		String[] nome = new String[10];
		float[] preco = new float[10];
		Scanner teclado = new Scanner (System.in);
		boolean condicao = true;
		
		System.out.println("Bem vindo!");
		while(condicao) {
			for (int j = 0; j < nome.length; j++) {
				System.out.print("Nome da pizza:  ");
				nome[j]= teclado.next();
				calc.setNome(nome);	
				System.out.print("Pre�o: ");
				preco[j] = teclado.nextFloat();
				calc.setPreco(preco);
				System.out.print("Tamanho/cm: ");
				float tamanho = teclado.nextFloat();
				calc.validaTamanho(tamanho);
				System.out.println("0 - para fazer outra opera��o ou N para sair:   ");
				String novacondicao = teclado.next();
				if(novacondicao.equalsIgnoreCase("N")) {
					condicao = false;
				}
				for (int i = 0; i < preco.length; i++) {
					System.out.println("Calculos tamanho");
					System.out.println(calc.getTamanho());
					
				}
			}
			
		}
		

	}

}
